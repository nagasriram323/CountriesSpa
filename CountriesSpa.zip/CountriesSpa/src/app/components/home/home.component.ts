import { Component, OnInit } from "@angular/core";
import { ApiService } from "src/app/services/api.service";
import { Subscription } from 'rxjs';

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.scss"]
})
export class HomeComponent implements OnInit {
  countries: any;
  countryDetails: any;
  selectedCountry: any;
  showCountryDetails: boolean;
  subscriptions: Array<Subscription> = [];

  constructor(private api: ApiService) {}

  ngOnInit() {
    this.getCountries();
  }

  getCountries() {
    this.subscriptions.push(this.api.getCountries().subscribe(res => {
      this.countries = res;
    }));
  }

  onCountryChanged() {
    this.countryDetails = null;
    this.subscriptions.push(this.api.getCountry(this.selectedCountry.alpha3Code).subscribe(res => {
      this.countryDetails = res[0];
      this.showCountryDetails = true;
    }));
  }

  UnregisterSubscriber(subscription: Subscription) {
    if (subscription) {
      subscription.unsubscribe();
      subscription = undefined;
    }
  }

  ngOnDestroy() {
    this.subscriptions.forEach(subscription =>
      this.UnregisterSubscriber(subscription));
  }
}
