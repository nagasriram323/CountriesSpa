import { Component, OnInit, OnDestroy } from "@angular/core";
import { ApiService } from "src/app/services/api.service";
import { ActivatedRoute } from "@angular/router";
import { Subscription } from 'rxjs';
import { Directive, HostListener } from '@angular/core';
import { Location } from '@angular/common';

@Component({
  selector: "app-country-details",
  templateUrl: "./country-details.component.html",
})
export class CountryDetailsComponent implements OnInit, OnDestroy {
  countryDetails: any;
  subscriptions: Array<Subscription> = [];

  constructor(private api: ApiService, private route: ActivatedRoute, private location: Location) {}

  ngOnInit() {
    this.getCountry();
  }



  getCountry() {
    const routeParams = this.route.snapshot.params;
    this.subscriptions.push(this.api.getCountry(routeParams.id).subscribe(res => {
      this.countryDetails = res[0];
    }));
  }

  @HostListener('click')
  onClick() {
    this.location.back();
  }

  UnregisterSubscriber(subscription: Subscription) {
    if (subscription) {
      subscription.unsubscribe();
      subscription = undefined;
    }
  }

  ngOnDestroy() {
    this.subscriptions.forEach(subscription =>
      this.UnregisterSubscriber(subscription));
  }
}
